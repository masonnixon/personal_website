#ifndef __hardwareInit_h__
#define __hardwareInit_h__

#include "includes.h"

void hardwareInit(void);

#endif