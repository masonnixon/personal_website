% Written by: Mason Nixon
% Version date: 11/02/2011
% clear all
clear actions robotScore
clc
numRuns = 200;

%Reading in world file
fileName='Can.wld';

[fid,msg] = fopen(fileName,'r+');
if fid < 0
    fprintf('Error in readDataFile: %s.\n', msg)
    dataMatrix=0;
else
    [dataMatrix,count]=fscanf(fid,'%c',inf);
    if count == 0
        fprintf('Error in readDataFile: No data in file.\n')
        fclose(fid);
    else
        % Parse dataMatrix
        fclose(fid);
    end
end

%Need to parse the char string into points for the grid 
dataValues = strread(dataMatrix, '%s', 'delimiter',' ');

% Origin x_position y_position  
%   Defines the starting (x,y) position of the robot  
origin = [str2double(dataValues{2}),str2double(dataValues{3})] + [1 1];
% Note: must add 1 everywhere since matlab index starts with 1
a3 = 1;
for a2 = 3:(length(dataValues))
    if(length(dataValues{a2}) == 3)
        cans(a3,1:2) = [str2double(dataValues{a2+1}),str2double(dataValues{a2+2})]+[1 1];
        a3 = a3 + 1;
    end
end
robotPos = origin; 

%Update map
mapOut = updateMap(robotPos, cans);
pause(0.7); %wait 0.7 second to show map updates

% % Setup Learned Strategy table
% learnedStrat(1:243,1:12) = 0;
% learnedStrat(:,6) = 7; % Assign 7 for no action learned yet
% for a4 = 1:3
%     % Assign zeros, ones, and twos
%     learnedStrat(((a4-1)*3^4)+1:(a4)*3^4,1) = (a4-1); % First column 3^4 1
%     for b1 = 1:3
%         learnedStrat(((a4-1)+(b1-1)*3)*3^3+1:(((a4-1)+(b1-1)*3)+1)*3^3,2) = (a4-1); % Second column 3^3 3
%     end
%     for b1 = 1:9
%         learnedStrat(((a4-1)+(b1-1)*3)*3^2+1:(((a4-1)+(b1-1)*3)+1)*3^2,3) = (a4-1); % Third column 3^2 9
%     end
%     for b1 = 1:27
%         learnedStrat(((a4-1)+(b1-1)*3)*3^1+1:(((a4-1)+(b1-1)*3)+1)*3^1,4) = (a4-1); % Fourth column 3^1 27
%     end
%     for b1 = 1:81
%         learnedStrat(((a4-1)+(b1-1)*3)*3^0+1:(((a4-1)+(b1-1)*3)+1)*3^0,5) = (a4-1); % Fifth column 3^0 81
%     end
% end

a1=1;
actions(1:numRuns) = 0;
robotScore = 0;
while(a1 <= numRuns) % Only iterates through this many times
    stateVec = canDet(mapOut(:,:,3), robotPos); % Determine the current state
    robotResp = robotDecision(stateVec, learnedStrat);
    robotAction = robotAct(robotResp, robotPos, cans, stateVec);
    
    if robotAction(3) ~= 0 % Must rewrite cans variable each time one is removed
        if robotAction(3) == 1 % If found first can on list
            [b2,b3] = size(cans);
            if b2 == 1
                newCans(:,1:2) = 0;    
            else
                newCans(:,1:2) = cans(2:length(cans(:,1:2)),1:2);    
            end
        elseif robotAction(3) == length(cans(:,1:2)) % If found last can on list
            newCans(:,1:2) = cans(1:(length(cans(:,1:2)))-1,1:2);
        else % If found can in midle of list
            newCans(1:(robotAction(3)-1),1:2) = cans(1:(robotAction(3)-1),1:2);
            newCans((robotAction(3)):(length(cans(:,1:2)))-1,1:2) = cans((robotAction(3)+1):(length(cans(:,1:2))),1:2);
        end
        clear cans
        cans = newCans;
        clear newCans
    end
    
    actions(a1) = robotResp; % Store previous actions
   
    scoreOut = scoreFunc(robotPos, stateVec, robotResp, robotAction); % For assignment
    robotPos = scoreOut(2:3); % Store robot position in a different variable
    robotScore = robotScore + scoreOut(1);
    
    myRobotScore = myScoreFunc(stateVec, robotResp); % For RL 
    reward = robotEval(scoreOut(1), stateVec, robotResp, learnedStrat, myRobotScore); % For RL
    index = strmatch(stateVec, learnedStrat(:,1:5)); % Update learning matrix
    learnedStrat(index,6:12) = reward(index,1:7);
    
    mapOut = updateMap(robotPos, cans);
    pause(0.0001); %wait 0.2 second to show map updates
    a1 = a1 + 1;
end

disp('End of run\n')