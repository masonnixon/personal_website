function response = robotDecision(stateVec, learnedStrat)
% Actions: 
% 0 - Move North
% 1 - Move South
% 2 - Move East
% 3 - Move West
% 4 - Pick up can
% 5 - Move Random
% 6 - Stay Put

% Search learnedStrat for stateVec and lookup the appropriate action (if it
% has already been defined)
index = strmatch(stateVec,learnedStrat(:,1:5));
action = learnedStrat(index,6);

% If no entry found (i.e. action = 7), randomly choose
if action == 7
    rN = rand(1);
    if (rN <= 1/6) % Six possibilities with equal probability ('Stay Put' not possible)
        action = 0;
    elseif ((rN > 1/6) && (rN <= 2/6))
        action = 1;
    elseif ((rN > 2/6) && (rN <= 3/6))
        action = 2;
    elseif ((rN > 3/6) && (rN <= 4/6))
        action = 3;
    elseif ((rN > 4/6) && (rN <= 5/6))
        action = 4;
    elseif ((rN > 5/6) && (rN <= 1))    
        action = 5;
    else 
        action = 6; % Should never occur
    end
end

% Check if situation has occured before, and if so what the reward was.
if (action == 8)
    % Look at the additonal 6 columns after column 6 where 1s indicate the
    % corresponding option has been tried before and it resulted in a
    % demerit.
 
    % Must determine which actions have not been tried yet
    zeroElements = (learnedStrat(index,7:12)) == 0; % Creates logical vector
    nonTried = find(zeroElements); % Zero elements found

    if (length(nonTried) == 1) % Which ever action had not been tried is the correct one
        action = nonTried - 1; % Actions are 1 less than array index
    elseif (length(nonTried) == 2) 
        rN = rand(1);
        if(rN <= 1/2)
            action = nonTried(2) - 1;
        else
            action = nonTried(1) - 1;
        end
    elseif (length(nonTried) == 3)
        rN = rand(1);
        if(rN <= 1/3)
            action = nonTried(3) - 1;
        elseif((rN > 1/3) || (rN <= 2/3))
            action = nonTried(1) - 1;
        elseif((rN > 2/3) || (rN <= 1))
            action = nonTried(2) - 1;
        end
    elseif (length(nonTried) == 4)
        rN = rand(1);
        if(rN <= 1/4)
            action = nonTried(4) - 1;
        elseif((rN > 1/4) || (rN <= 2/4))
            action = nonTried(2) - 1;
        elseif((rN > 2/4) || (rN <= 3/4))
            action = nonTried(1) - 1;
        elseif((rN > 3/4) || (rN <= 1))
            action = nonTried(3) - 1;
        end
    elseif (length(nonTried) >= 4)
        rN = rand(1);
        if(rN <= 1/5)
            action = nonTried(3) - 1;
        elseif((rN > 1/5) || (rN <= 2/5))
            action = nonTried(5) - 1;
        elseif((rN > 2/5) || (rN <= 3/5))
            action = nonTried(2) - 1;
        elseif((rN > 3/5) || (rN <= 4/5))
            action = nonTried(1) - 1;
        elseif((rN > 4/5) || (rN <= 1))
            action = nonTried(4) - 1;
        end
    end
end

response = action;
end