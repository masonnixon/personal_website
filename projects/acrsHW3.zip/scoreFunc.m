function out = scoreFunc(robotPos, stateVec, response, robotAction)
% 10 pts for picking up can, -1 for no can and try to pick up, -5 for
% running into wall. response = action; robotAction = [xPos, yPos, canIndex];
robotScore = 0;

% Ran into wall
if (robotAction(1) <= 0 || robotAction(2) <= 0)
    robotScore = -5; % Also, robotPos goes back to previous.
elseif (robotAction(1) >= 11 || robotAction(2) >= 11)
    robotScore = -5; % Also, robotPos goes back to previous.
else
    robotPos = robotAction(1:2);
end

% Cans
if stateVec(5) == 1 % Can is present
    if response == 4 % Can was picked up
        robotScore = 10;
    end
elseif stateVec(5) ~= 1 % No can present
    if response == 4 % Can was attempted to be picked up
        robotScore = -1;
    end    
end

out = [robotScore robotPos];
end