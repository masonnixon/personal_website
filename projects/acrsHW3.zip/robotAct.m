function out = robotAct(action, robotPos, cans, stateVec)
% Note: x is the vertical axis, and y is horizontal axis
xPos = robotPos(1);
yPos = robotPos(2);
canIndex = 0;

switch action
    case 0 % 0 - Move North
        xPos = robotPos(1) - 1; 
        yPos = robotPos(2);
    case 1 % 1 - Move South
        xPos = robotPos(1) + 1; 
        yPos = robotPos(2);
    case 2 % 2 - Move East
        xPos = robotPos(1);
        yPos = robotPos(2) + 1;
    case 3 % 3 - Move West
        xPos = robotPos(1);
        yPos = robotPos(2) - 1;
    case 4 % 4 - Pick up can
        if stateVec(5) == 1 % Can is present
            canIndex = strmatch(robotPos,cans(:,1:2)); % Which can?
        end
    case 5 % 5 - Move Random
        rn = rand(1);
        if (rn <= 1/4) % Move North
            xPos = robotPos(1) - 1; 
            yPos = robotPos(2);
        elseif ((rn > 1/4) && (rn <= 1/2)) % Move South
            xPos = robotPos(1) + 1;
            yPos = robotPos(2);
        elseif ((rn > 1/2) && (rn <= 3/4)) % Move E
            xPos = robotPos(1);
            yPos = robotPos(2) + 1;
        elseif ((rn > 3/4) && (rn <= 1)) % Move W
            xPos = robotPos(1);
            yPos = robotPos(2) - 1;
        else % Should never occur
            xPos = robotPos(1);
            yPos = robotPos(2);
        end
    otherwise
end

newPosition = [xPos, yPos];
out = [newPosition, canIndex];
end