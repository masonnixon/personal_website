function myRobotScore = myScoreFunc(stateVec, robotResp)
myRobotScore = 0;

if ((stateVec(5) == 1) && (robotResp ~= 4))
    % If a can is present and the robot did not pick it up, -1
    myRobotScore = -1;
elseif ((stateVec(5) ~= 1) && (stateVec(1) == 1) && (robotResp ~= 0))
    % Move toward N cans if not on can
    myRobotScore = -6;
elseif ((stateVec(5) ~= 1) && (stateVec(2) == 1) && (robotResp ~= 1))
    % Move toward S cans if not on can
    myRobotScore = -7;
elseif ((stateVec(5) ~= 1) && (stateVec(3) == 1) && (robotResp ~= 2))
    % Move toward E cans if not on can
    myRobotScore = -8;
elseif ((stateVec(5) ~= 1) && (stateVec(4) == 1) && (robotResp ~= 3))
    % Move toward W cans if not on can
    myRobotScore = -9;      
end