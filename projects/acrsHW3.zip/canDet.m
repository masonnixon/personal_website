function stateVector = canDet(canMap, robotPos)
% canMap contains the can layer (20 pixels by 20 pixels)
% robotPos has the current robot position

stateVector = [0, 0, 0, 0, 0]; % N,S,E,W, Current Site

% Look for cans and walls
% Check North
if (robotPos(1)-1 < 1)
    stateVector(1) = 2; % 2 signifies a wall
else
    canFind = canMap(robotPos(1)-1, robotPos(2));
    if(canFind==0) %If zeros are found, then can has been detected
        stateVector(1) = 1; % 1 signifies a can
    end
end

% Check South
if (robotPos(1)+1 > 10)
    stateVector(2) = 2;
else
    canFind = canMap(robotPos(1)+1, robotPos(2));
    if(canFind==0) %If zeros are found, then can has been detected
        stateVector(2) = 1; % 1 signifies a can
    end
end

% Check East
if (robotPos(2)+1 > 10)
    stateVector(3) = 2;
else
    canFind = canMap(robotPos(1), robotPos(2)+1);
    if(canFind==0) %If zeros are found, then can has been detected
        stateVector(3) = 1; % 1 signifies a can
    end
end

% Check West
if (robotPos(2)-2 < 1)
    stateVector(4) = 2;
else
    canFind = canMap(robotPos(1), robotPos(2)-1);
    if(canFind==0) %If zeros are found, then can has been detected
        stateVector(4) = 1; % 1 signifies a can
    end
end

% Check Current
canFind = canMap(robotPos(1), robotPos(2));
if(canFind==0) %If zeros are found, then can has been detected
    stateVector(5) = 1; % 1 signifies a can
end

end