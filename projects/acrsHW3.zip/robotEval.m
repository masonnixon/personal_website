function reward = robotEval(robotScore, stateVec, action, learnedStrat, myRobotScore)
% Determine the reward. Come up with positive reinforcement for good
% behavior and negative reinforcement for bad. Ex. If can is to North, and
% robot went a different route, then store the bad score such that the
% robot will not choose this action next time.
reward(243,1:7) = 0;
index = strmatch(stateVec,learnedStrat(:,1:5));

% Store the bad actions in 6 additional columns in learnedStrat.
if (robotScore == 10) % Want to pick up can in this scenario
    learnedStrat(index,6) = 4;
elseif (robotScore == -1) || (robotScore == -5) % Don't do these again
    learnedStrat(index,6) = 8;
    learnedStrat(index,action+7) = 1;
% elseif (robotScore == 0) % If no bad score, then this action is okay to do
%     learnedStrat(index,6) = action;
end

if(myRobotScore == -1) % Should have picked up a can
    learnedStrat(index,6) = 4;
elseif(myRobotScore == -2) % Should have moved South
    learnedStrat(index,6) = 1;
elseif(myRobotScore == -3) % Should have moved North
    learnedStrat(index,6) = 0;
elseif(myRobotScore == -4) % Should have moved East
    learnedStrat(index,6) = 2;
elseif(myRobotScore == -5) % Should have moved West
    learnedStrat(index,6) = 3;
elseif(myRobotScore == -6) % Should have moved North
    learnedStrat(index,6) = 0;    
elseif(myRobotScore == -7) % Should have moved South
    learnedStrat(index,6) = 1;    
elseif(myRobotScore == -8) % Should have moved East
    learnedStrat(index,6) = 2;        
elseif(myRobotScore == -9) % Should have moved West
    learnedStrat(index,6) = 3;   
elseif(myRobotScore == -10) % Should have moved West
    learnedStrat(index,6) = 2;     
end

reward(index,1:7) = learnedStrat(index,6:12);
end