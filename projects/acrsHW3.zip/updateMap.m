function mapOutput = updateMap(robotPos, cans)
map = ones(10,10);

%Cans Blue layer
[b1,b2] = size(cans); % Determine the number of cans in the room

if (b1 == 1) && (cans(1,1) == 0) % Do nothing
else
    for a1 = 1:b1
        map(cans(a1,1),cans(a1,2)) = 0;
    end
end
img2(:,:,3)=map; % Blue layer

%Robot Green Layer
map(robotPos(1), robotPos(2)) = 0; 
%Cans Green Layer
if (b1 == 1) && (cans(1,1) == 0) % Do nothing
else
    for a1 = 1:b1
        map(cans(a1,1),cans(a1,2)) = 1;
    end
end
img2(:,:,2)=map; % Green layer

%Cans
if (b1 == 1) && (cans(1,1) == 0) % Do nothing
else
    for a1 = 1:b1
        map(cans(a1,1),cans(a1,2)) = 1;
    end
end
img2(:,:,1)=map; % Red layer

bigMap = imresize(img2, [306 540], 'bilinear'); % Resize map to make larger
imwrite(bigMap,'map.jpg');
imshow('map.jpg')
title('Room Map')
mapOutput = img2;

end