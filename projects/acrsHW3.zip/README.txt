Name: Mason Nixon
Version Date: 11/10/2011
Course: GA Tech ECE 8843: Autonomous Control of Robotic Systems
Description: HW3 - Learning Robot Control Stategies
The following is instruction on how to run the MATLAB (R2009b) m-files.
Due: 11/09/2011
Files included: canDet.m, updateMap.m, myScoreFunc.m, robotAct.m, 
robotDecision.m, robotEval.m, scoreFunc.m, HW3main.m

Instructions: With these eight (8) m-files in the same directory as 
Can.wld open HW3main.m and run it. The current setup is for the 200 
iteration runs. If this needs to be changed, change the numRuns variable
at the top of HW3main.m. 

Also, the learnedStrat learning strategy matrix is created from scratch 
the first run. If you desire to import my matrix, it is included in the 
.zip folder as 'learnedStrat.mat' and you must comment out lines 46 
through 64 in HW3main.m.

Note: The output is being plotted on an image of size 10x10 pixels. The 
image is scaled up for ease of viewing. Unfotunately, there is some blur 
around the edges of each object in the image.