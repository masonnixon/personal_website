Name: Mason Nixon
Version Date: 09/22/2011
Course: GA Tech ECE 8843: Autonomous Control of Robotic Systems
Description: HW1 - Vision-Based Robot Localization
The following is instruction on how to run the homework files and the 
appropriate solutions associated with HW1.
Due: 09/28/2011
Files included: ptDistance.m, LineCenter.m, robotPosOri.m, HW1main.m

Instructions: With these four (4) m-files in the same directory as 
robotstart.jpg and robotvalidate(1-6).jpg open HW1main.m and run it.

************************************
m-File Descriptions:
ptDistance.m
% Find distance between two points
% Syntax: [distance] = ptDistance(x1,x2,y1,y2)

LineCenter.m
% Find Center of two points
% Syntax: [xCenter, yCenter] = LineCenter(x1,x2,y1,y2)

robotPosOri.m
% This function calculates the position and orientation of a robot that is
% indicated by three orange dots on its top. It is assumed that:
%   1) The dots are orange
%   2) The dots are fully visible and unobstructed
%   3) No other orange, red, or yellow circles are present
%   4) The dots form an iscoceles triangle on the robot in which the left 
%      of the robot is indicated by the base of the triangle when the 
%      robot is facing South (see below). 
%   5) The area of the robot does not exceed 4600 pixels
%   6) The center of the triangle of dots is the center of the robot
%
% Usage [x, y, direction] = robotPosOri('imageFile.jpg')
% where 'imageFile' is an image of said robot in .jpg format and x,y is the
% position of the robot in pixelspace. 'direction' is the direction the
% robot is facing with the following convention: 0 degrees is South, 180
% degrees is North, 90 degrees is West, and 270 degrees is East.
%

HW1main.m
% Description: This m-file utilizes ptDistance.m, LineCenter.m, and
% robotPosOri.m and determines the change in position and orientation 
% between each frame of the images: robotstart.jpg and
% robotvalidate(1-6).jpg. It also assesses how far the robot has physically
% travelled between each frame and also the shortest trajectory from
% robotstart.jpg to robotvalidate6.jpg. After calculating these parameters,
% the results are displayed on the Command Window in MATLAB.
% 

*************************************

Solutions: 
Part C-0
The robot has travelled the following 6 distances (in pixels) between each frame: 
  753   952   843   628   698   848 
The changes in orientation (in degrees) between each frame are: 
 0.0066  -45.0268  -44.9644  90.0110  89.9714  -44.9228 
 
Part C-1
How far has the robot physically travelled from start to goal (in pixel space)?
(Assuming the robot moves between frames in straight-line paths) 
Physical Travelled Distance =  4721 pixels 
 
Part C-2
What is the shortest trajectory (i.e. minimum distance and rotation) to get the 
robot from start to goal location? 
(Assuming the robot can rotate about its centroid) 
Minimum distance = 3964 pixels, Minimum rotation = 45.07 degrees
