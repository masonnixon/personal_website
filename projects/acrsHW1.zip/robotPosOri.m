% Written by: Mason Nixon
% Version date: 09/22/2011
% Description:
% This function calculates the position and orientation of a robot that is
% indicated by three orange dots on its top. It is assumed that:
%   1) The dots are orange
%   2) The dots are fully visible and unobstructed
%   3) No other orange, red, or yellow circles are present
%   4) The dots form an iscoceles triangle on the robot in which the left 
%      of the robot is indicated by the base of the triangle when the 
%      robot is facing South (see below). 
%   5) The area of the robot does not exceed 4600 pixels
%   6) The center of the triangle of dots is the center of the robot
%
% Usage [x, y, direction] = robotPosOri('imageFile.jpg')
% where image file is an image of said robot in .jpg format and x,y is the
% position of the robot in pixelspace. 'direction' is the direction the
% robot is facing with the following convention: 0 degrees is South, 180
% degrees is North, 90 degrees is West, and 270 degrees is East.
%

function [xCentroid, yCentroid, globalDirection] = robotPosOri(imageFile)

    % Determine the position of the robot in pixelspace
    % Read the image
    if(exist(imageFile,'file') == 0)
        error('File not found',fprintf('File %s is not in the current directory.', imageFile));
    else
        robotimg1 = imread(imageFile);
        %imshow(robotimg1) % Better way to display the image

        % Extract the red image to filter noise
        robotimg1 = robotimg1(:,:,1);

    %***Code derived from the following address***
    % MATLAB circle find: http://www.mathworks.com/products/image/demos.html?file=/products/demos/s
    % hipping/images/ipexroundness.html
    % This portion of code was found at the above website and modified for use
    % in this assignment. It's function is to locate and rank objects that seem
    % to be circular.

        % Threshold the image and convert to black and white
        threshold = graythresh(robotimg1);
        bwRobotimg1 = im2bw(robotimg1,threshold);

        % Remove the noise
        % remove all objectS containing fewer than 30 pixels
        bwRobotimg1 = bwareaopen(bwRobotimg1,50);

        % Find the Boundaries that are circular
        [B,L] = bwboundaries(bwRobotimg1,'noholes');

        % Determine which Objects are Round
        stats = regionprops(L,'Area','Centroid');
        threshold = 0.80;
        % loop over the boundaries
        for k = 1:length(B)
          % obtain (X,Y) boundary coordinates corresponding to label 'k'
          boundary = B{k};
          % compute a simple estimate of the object's perimeter
          delta_sq = diff(boundary).^2;
          perimeter = sum(sqrt(sum(delta_sq,2)));
          % obtain the area calculation corresponding to label 'k'
          area = stats(k).Area;
          % compute the roundness metric
          metric = 4*pi*area/perimeter^2;
          % mark objects above the threshold with a black circle
          if metric > threshold
            centroid = stats(k).Centroid;
          end
        end
    %***End cited code***

        % Find the three circle's centroids
        a1 = 1; circles = [0,0;0,0;0,0];
        for k = 1:length(stats)
            if(stats(k).Area < 4600) %Isolate the circle objects
                circles(a1,1:2) = stats(k).Centroid;
                a1 = a1+1;
            end
        end

        % Find which point is which
        x1 = circles(1,1); y1 = circles(1,2); 
        x2 = circles(2,1); y2 = circles(2,2);
        x3 = circles(3,1); y3 = circles(3,2);
        d(1) = ptDistance(x1,x2,y1,y2);
        d(2) = ptDistance(x1,x3,y1,y3);
        d(3) = ptDistance(x2,x3,y2,y3);
        [minVal,minIndex] = min(d);

        if(minIndex == 1) % 1 to 2 is shortest, ie 3 is outlier
            xShort = [x1 x2]; yShort = [y1 y2];
            xLong = x3; yLong = y3;
        elseif(minIndex == 2) % 1 to 3 is shortest, ie 2 is outlier
            xShort = [x1 x3]; yShort = [y1 y3];
            xLong = x2; yLong = y2;
        elseif(minIndex == 3) % 2 to 3 is shortest, ie 1 is outlier
            xShort = [x2 x3]; yShort = [y2 y3];
            xLong = x1; yLong = y1;
        end

        % Find the center of the short line
        [xSCenter, ySCenter] = LineCenter(xShort(1),xShort(2),yShort(1),yShort(2));

        % Finally, find the centroid of the triangle (robot position)
        xLong = [xSCenter xLong]; yLong = [ySCenter yLong];
        [xCentroid, yCentroid] = LineCenter(xLong(1),xLong(2),yLong(1),yLong(2));

        % Now, determine orientation
        % Need another line parallel to centerline of triangle.
        % Determine which dot is the back of the robot by comparing to the
        % outlier dot.
        if(ySCenter > yLong(2) + 25) % val5,val6,val4(+10)
           if(xSCenter > xShort(1)+ 10)
               xRRear = xCentroid + (xCentroid - xShort(1));
               yRRear = yCentroid + (yCentroid - yShort(1)); 
               [xCRear,yCRear] = LineCenter(xRRear,xShort(2),yRRear,yShort(2));
           else
               xRRear = xCentroid + (xCentroid - xShort(2));
               yRRear = yCentroid + (yCentroid - yShort(2)); 
               [xCRear,yCRear] = LineCenter(xRRear,xShort(1),yRRear,yShort(1));
           end
        else % val2,val3,val1(+25)
           if(xSCenter > xShort(1))
               xRRear = xCentroid + (xCentroid - xShort(2));
               yRRear = yCentroid + (yCentroid - yShort(2)); 
               [xCRear,yCRear] = LineCenter(xRRear,xShort(1),yRRear,yShort(1));
           else
               xRRear = xCentroid + (xCentroid - xShort(1));
               yRRear = yCentroid + (yCentroid - yShort(1)); 
               [xCRear,yCRear] = LineCenter(xRRear,xShort(2),yRRear,yShort(2));
           end
        end

        % Now create a line that goes to the wall the robot is facing
        xDelta = (xCentroid - xCRear);
        yDelta = (yCentroid - yCRear);
        xOrient = xDelta + xCentroid; yOrient = yDelta + yCentroid; 

        for a2 = 2:length(bwRobotimg1(1,:))
            xOrient = a2*xDelta/10 + xCentroid;
            yOrient = a2*yDelta/10 + yCentroid;
            if(xOrient >= length(bwRobotimg1(1,:)))
                xOrient = length(bwRobotimg1(1,:)); % x dimension max (1020)
                directionFacing = 270; % Facing East
                xPerp = xOrient;
                yPerp = yCRear;
                if(yOrient > yPerp) % Used for global direction
                    angleOperator = 1; % 1 = add the directionFacing to robotOrientation
                else
                    angleOperator = 0; % 0 = subtract the robotOrientation from directionFacing
                end            
                break;
            elseif(yOrient >= length(bwRobotimg1(:,1)))
                yOrient = length(bwRobotimg1(:,1)); % y dimension max (340)
                directionFacing = 0; % Facing South
                xPerp = xCRear;
                yPerp = yOrient;
                if(xOrient < xPerp) % Used for global direction
                    angleOperator = 1; % 1 = add the directionFacing to robotOrientation
                else
                    angleOperator = 2; % 2 = subtract the robotOrientation from 360 degrees
                end            
                break;
            elseif(xOrient <= 1)
                xOrient = 1;
                directionFacing = 90; % Facing West
                xPerp = xOrient;
                yPerp = yCRear;
                if(yOrient < yPerp) % Used for global direction
                    angleOperator = 1; % 1 = add the directionFacing to robotOrientation
                else
                    angleOperator = 0; % 0 = subtract the robotOrientation from directionFacing
                end
                break;
            elseif(yOrient <= 1)
                yOrient = 1;
                directionFacing = 180; % Facing North
                xPerp = xCRear;
                yPerp = yOrient;            
                if(xOrient > xPerp) % Used for global direction
                    angleOperator = 1; % 1 = add the directionFacing to robotOrientation
                else
                    angleOperator = 0; % 0 = subtract the robotOrientation from directionFacing
                end
                break;
            end
        end

        % Calculate the arccosine(=arccos(adjacent/hypotenuse))
        hypotenuse = ptDistance(xCRear,xOrient,yCRear,yOrient);
        adjacent = ptDistance(xCRear,xPerp,yCRear,yPerp);
        robotOrientation = acosd(adjacent/hypotenuse);

        % Find direction in global map
        if(angleOperator == 1)
            globalDirection = directionFacing + robotOrientation;
        elseif(angleOperator == 0)
            globalDirection = directionFacing - robotOrientation;
        else % angleOperator == 2 => subtracting from 0 degrees
            globalDirection = 360 - robotOrientation;
        end

    end
end