% Written by: Mason Nixon
% Version date: 09/22/2011
% Description:
% Find Center of two points
% Syntax: [xCenter, yCenter] = LineCenter(x1,x2,y1,y2)
% 
function [xCenter, yCenter] = LineCenter(x1,x2,y1,y2)

    if(x1 > x2)
        if(y1 > y2)
            xCenter = x1-abs(x1-x2)/2; 
            yCenter = y1-abs(y1-y2)/2;
        else % y2 > y1
            xCenter = x1-abs(x1-x2)/2;
            yCenter = y2-abs(y1-y2)/2;
        end
    else % x2 > x1
        if(y1 > y2)
            xCenter = x2-abs(x1-x2)/2;
            yCenter = y1-abs(y1-y2)/2;           
        else % y2 > y1
            xCenter = x2-abs(x1-x2)/2;
            yCenter = y2-abs(y1-y2)/2;
        end
    end

end
