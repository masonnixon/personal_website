% Written by: Mason Nixon
% Version date: 09/22/2011
% Description:
% Find distance between two points
% Syntax: [distance] = ptDistance(x1,x2,y1,y2)
% 
function [distance] = ptDistance(x1,x2,y1,y2)
    distance = sqrt(abs(x1-x2)^2+abs(y1-y2)^2);
end