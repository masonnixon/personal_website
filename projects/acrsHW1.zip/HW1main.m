% Written by: Mason Nixon
% Version date: 09/22/2011
% Description: This m-file utilizes ptDistance.m, LineCenter.m, and
% robotPosOri.m and determines the change in position and orientation 
% between each frame of the images: robotstart.jpg and
% robotvalidate(1-6).jpg. It also assesses how far the robot has physically
% travelled between each frame and also the shortest trajectory from
% robotstart.jpg to robotvalidate6.jpg. After calculating these parameters,
% the results are displayed on the Command Window in MATLAB.
% 

clear all 
clc

% Initialize the position, orientation, and distance variables
xPos(7) = 0;
yPos(7) = 0;
theta(7) = 0;
distances(6) = 0;
orientation(6) = 0;

% Find the initial position and orientation of the robot
imageFile = 'robotstart.jpg';
[xPos(1),yPos(1),theta(1)]=robotPosOri(imageFile);

% Determine the parameters of each successive robot image
for a1 = 2:7
    imageFile = sprintf('robotvalidate%1.0g.jpg',(a1-1));
    [xPos(a1),yPos(a1),theta(a1)]=robotPosOri(imageFile);
    % Determine the relative distance travelled between each frame (Part C)
    distances(a1-1) = ptDistance(xPos(a1-1),xPos(a1),yPos(a1-1),yPos(a1));
    if(theta(a1) > theta(a1-1))
        orientation(a1-1) = theta(a1) - theta(a1-1);
    else
        if(theta(a1-1) > 270 && theta(a1) < 90)
            orientation(a1-1) = theta(a1-1) - theta(a1);
            orientation(a1-1) = 360 - orientation(a1-1);
        else
            orientation(a1-1) = -1*(theta(a1-1) - theta(a1));
        end
    end
end

% Determine how far the robot has physically travelled from start to goal.
% I assume the robot is moving in straight-line paths and that it can
% rotate about its centroid.
pDistance = sum(distances);

% Determine the shortest trajectory. Note: I assume that this is a straight
% line from start to finish.
sDistance = ptDistance(xPos(1),xPos(7),yPos(1),yPos(7));
if(theta(7) > theta(1))
    sOrientation = theta(7) - theta(1);
else
    if(theta(1) > 270 && theta(7) < 90)
        sOrientation = theta(1) - theta(7);
        sOrientation = 360 - sOrientation;
    else
        sOrientation = -1*(theta(1) - theta(7));
    end
end

% Display Results
disp('Part C-0')
fprintf('The robot has travelled the following 6 distances (in pixels) between each frame: \n %4.0f  %4.0f  %4.0f  %4.0f  %4.0f  %4.0f \n', distances);
fprintf('The changes in orientation (in degrees) between each frame are: \n %3.4f  %3.4f  %3.4f  %3.4f  %3.4f  %3.4f \n \n', orientation);

disp('Part C-1')
disp('How far has the robot physically travelled from start to goal (in pixel space)?')
disp('(Assuming the robot moves between frames in straight-line paths) ')
fprintf('Physical Travelled Distance = %5.0f pixels \n \n', pDistance)

disp('Part C-2')
disp('What is the shortest trajectory (i.e. minimum distance and rotation) to get the ')
disp('robot from start to goal location? ')
disp('(Assuming the robot can rotate about its centroid) ');
fprintf('Minimum distance = %4.0f pixels, Minimum rotation = %2.2f degrees\n',sDistance,sOrientation)


