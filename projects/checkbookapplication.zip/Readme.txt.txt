DigitalCheckbook.exe
Last Update: 09/14/2012
Ver. 0.7.0

This program allows a user to collect all transactions that would normally be collected in a checkbook register into a CSV, or comma-separated value, file. This allows the user to view all transactions in a spreadsheet using Microsoft Excel or the OpenOffice spreadsheet tool.

First either select the Bank account or Credit Card tab. Then fill the rest of the information as you would a normal checkbook. After filling all information, select "Next Transaction" to load that entry onto the list. The entries can be deleted and re-entered if they need to be altered. After all transactions have been added to the list, select "Write to CSV." The file is written in the format MONTHYEAR.csv and is by default saved to C://DigitalCheckbook/Checking/ or C://DigitalCheckbook/Credit Card/ .

The files are automatically stored to the month of the first transaction date you enter by default, however, you can change the month and year of the file to write by using the drop down menus to the left of the "Write to CSV" button.

Old CSV files can also be read in by selecting the drop down menus to the right of "Read CSV" button and inputting the month and year of the file you would like to read in. Transactions can be added or removed from the loaded CSV. To rewrite the CSV, select the month and year you would like to write the transactions in to and click "Write to CSV."

For issues, you can contact the developer directly at: Sekkou527@aol.com

Enjoy!