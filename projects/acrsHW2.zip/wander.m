function wanderVars = wander(maxVelocity, turns)
% Potential field
% Occasionally change motion at random (rand generates random number)

velChange = rand; %Between 0 and 1
%Velocities: Max Velocity/(1, 2, 3, or 4) meters/frame
if velChange <= 0.25
    wanderVel = maxVelocity;
elseif velChange > 0.25 && velChange < 0.5
    wanderVel = maxVelocity/2;
elseif velChange >= 0.5 && velChange < 0.75
    wanderVel = maxVelocity/3;
elseif velChange >= 0.75
    wanderVel = maxVelocity/4;
end

turnChange = rand;
%Direction: 1=North, 2=South, 3=East, 4=West
if turnChange <= 0.25
    wanderTurn = turns(1);
elseif turnChange > 0.25 && turnChange < 0.5
    wanderTurn = turns(2);
elseif turnChange >= 0.5 && turnChange < 0.75
    wanderTurn = turns(3);
elseif turnChange >= 0.75
    wanderTurn = turns(4);
end

wanderVars = [wanderVel wanderTurn];

end