function mapOutput = updateMap(robotPos, obstacle, beacon)
map = ones(20,20);

%Robot Blue layer
map(robotPos(1), robotPos(2)) = 0; 
%Beacons Blue layer
for a1 = 1:length(beacon)
    map(beacon(a1,2),beacon(a1,1)) = 0; 
end
img2(:,:,3)=map; % Blue layer

%Robot Green Layer
map(robotPos(1), robotPos(2)) = 0; 
%Obstacles Green Layer
[rows,cols]=size(obstacle);
for a4=1:rows
    map(obstacle(a4,2):obstacle(a4,2)+obstacle(a4,4)-1,obstacle(a4,1):obstacle(a4,1)+obstacle(a4,3)-1)=zeros(obstacle(a4,4),obstacle(a4,3));
end
%Beacons Green Layer
for a1 = 1:length(beacon)
    map(beacon(a1,2),beacon(a1,1)) = 1; 
end
img2(:,:,2)=map; % Green layer

%Robot Red layer
map(robotPos(1), robotPos(2)) = 1; 
%Beacons
for a1 = 1:length(beacon)
    map(beacon(a1,2),beacon(a1,1)) = 1; 
end
img2(:,:,1)=map; % Red layer

bigMap = imresize(img2, [306 540], 'bilinear'); % Resize map to make larger
imwrite(bigMap,'map.jpg');
imshow('map.jpg')
title('Room Map')
mapOutput = img2;

end