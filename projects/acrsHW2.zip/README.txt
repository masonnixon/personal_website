Name: Mason Nixon
Version Date: 10/12/2011
Course: GA Tech ECE 8843: Autonomous Control of Robotic Systems
Description: HW2 - Combining Robot Behaviors
The following is instruction on how to run the MATLAB (R2009b) m-files.
Due: 10/12/2011
Files included: wander.m, updateMap.m, move.m, avoid.m, beaconDet.m, HW2main.m

Instructions: With these six (6) m-files in the same directory as Room.wld open HW2main.m and run it. 

Note: The output is being plotted on an image of size 20x20 pixels. The image is scaled up for ease of viewing. Unfotunately, there is some blur around the edges of each object in the image.