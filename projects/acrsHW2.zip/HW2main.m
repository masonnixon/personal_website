% Written by: Mason Nixon
% Version date: 10/12/2011

clear 
clc

%Reading in world file
fileName='Room.wld';

[fid,msg] = fopen(fileName,'r+');
if fid < 0
    fprintf('Error in readDataFile: %s.\n', msg)
    dataMatrix=0;
else
    [dataMatrix,count]=fscanf(fid,'%c',inf);
    if count == 0
        fprintf('Error in readDataFile: No data in file.\n')
        fclose(fid);
    else
        % Parse dataMatrix
        fclose(fid);
    end
end

%Need to parse the char string into points for the grid 
dataValues = strread(dataMatrix, '%s', 'delimiter',' ');

% Origin x_position y_position  
%   Defines the starting (x,y) position of the robot  
origin = [str2double(dataValues{2}),str2double(dataValues{3})] + [1 1];
% Note: must add 1 everywhere since matlab index starts with 1
a3 = 1; a4 = 1;
for a2 = 4:(length(dataValues)-4)
    if(length(dataValues{a2}) == 6)
        % Beacon x_position y_position 
        %   Defines the (x,y) location of a beacon
        beacon(a3,1:2) = [str2double(dataValues{a2+1}),str2double(dataValues{a2+2})]+[1 1];
        a3 = a3 + 1;
    elseif(length(dataValues{a2}) == 8)
        % Obstacle x_position y_position width height 
        %   Defines the width and height of an obstacle, starting at (x,y) 
        obstacle(a4,1:4) = [str2double(dataValues{a2+1}),str2double(dataValues{a2+2}),str2double(dataValues{a2+3}),str2double(dataValues{a2+4})]+[1 1 1 1];
        a4 = a4 + 1;
    end
end
% Laserrange max_range  
%   Defines the maximum sensing range of the laser with respect to obstacles in the environment 
laserR = str2double(dataValues{length(dataValues)-2});
% Beaconrange max_range 
%   Defines the maximum sensing range with respect to the beacon 
beaconR = str2double(dataValues{length(dataValues)});
robotPos = origin; 

%Update map
mapOut = updateMap(robotPos, obstacle, beacon);
pause(0.7); %wait 0.7 second to show map updates

%Move constants
maxVelocity = 4; %Up to 4 frames/s
turns = [1 2 3 4]; %1=North, 2=South, 3=East, 4=West
wanderVar = wander(maxVelocity, turns); % Initialize

a1=0;
while(a1 < 10000) % Only iterates through this many times
    %Wander
    if(mod(a1,4) > 0) % Every 4 iterations, change wander value
        wanderVar = wander(maxVelocity, turns);
    end
    %Avoid Obstacles
    % Scan for obstacles in path
    avoidVar = avoid(mapOut(:,:,2), laserR, robotPos); 
    
    %Go to Beacon
    % Scan for beacons in path
    beaconVar = beaconDet(mapOut(:,:,3), beaconR, robotPos); % Pass in Beacon values
    if(beaconVar(3) == 1)
        break; % end loop        
    end
    %Combine
    % Write vector_combine function with Gain matrix
    gainMat = [0.5,1.2,1.25]; %wander;avoid obs;go to beacon
    velVecCombine = gainMat*[wanderVar(1);avoidVar(1);beaconVar(1)];
    [y,i] = max(gainMat.*[wanderVar(1),avoidVar(1),beaconVar(1)]);
    switch i
        case 1;
            turnVecCombine = wanderVar(2);           
        case 2;
            turnVecCombine = avoidVar(2);           
        case 3;
            turnVecCombine = beaconVar(2);
    end
    
    %Convert vector_combine to "Move" command (velocity and turn)
    posChange = [floor(velVecCombine), turnVecCombine];
    robotPos = move(posChange, robotPos);
    
    %Update map
    mapOut = updateMap(robotPos, obstacle, beacon);
    pause(0.7); %wait 0.7 second to show map updates
    
    a1 = a1 + 1;
end