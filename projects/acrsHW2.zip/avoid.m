function avoidVars = avoid(obsMap, laserR, robotPos)
% obsMap contains the obstacle layer (20 pixels by 20 pixels)
% robotPos has the current robot position
  
obsDirection = [0, 0, 0, 0]; %Closeness in N,S,E,W

% East
if((robotPos(2)+laserR > 20) && (robotPos(2) ~= 20))
    minX = robotPos(2) + 1;
    maxX =  20;
    obsFind = obsMap(robotPos(1), minX:maxX); %N
    if(~isempty(find(obsFind==0, 1))) %If zeros are found, then obstacle has been detected
       b1 = find(obsFind==0);
       obsDirection(4) = b1(1); %Want to move West
    end
elseif(robotPos(2) == 20)
    obsDirection(4) = 1; % if at the wall, move away
else
    minX = robotPos(2) + 1;
    maxX = robotPos(2) + laserR;
    obsFind = obsMap(robotPos(1), minX:maxX); %N
    if(~isempty(find(obsFind==0, 1))) %If zeros are found, then obstacle has been detected
       b1 = find(obsFind==0);
       obsDirection(4) = b1(1); %Want to move West
    end
end

% West
if((robotPos(2)-laserR < 1) && (robotPos(2) ~= 1))
    minX = 1;
    maxX =  robotPos(2) - 1;
    obsFind = fliplr(obsMap(robotPos(1), minX:maxX)); %S
    if(~isempty(find(obsFind==0, 1))) %If zeros are found, then obstacle has been detected
       b1 = find(obsFind==0);
       obsDirection(3) = b1(1); %Want to move East
    end
elseif(robotPos(2) == 1)
    obsDirection(3) = 1; % if at the wall, move away
else
    minX = robotPos(2) - laserR;
    maxX = robotPos(2) - 1;
    obsFind = fliplr(obsMap(robotPos(1), minX:maxX)); %S
    if(~isempty(find(obsFind==0, 1))) %If zeros are found, then obstacle has been detected
       b1 = find(obsFind==0);
       obsDirection(3) = b1(1); %Want to move East
    end
end
    
% South
if((robotPos(1)+laserR > 20) && (robotPos(1) ~= 20))
    minY = robotPos(1) + 1;
    maxY =  20;
    obsFind = obsMap(minY:maxY, robotPos(2)); %E
    if(~isempty(find(obsFind==0, 1))) %If zeros are found, then obstacle has been detected
       b1 = find(obsFind==0);
       obsDirection(1) = b1(1); %Want to move North
    end
elseif(robotPos(1) == 20)
    obsDirection(1) = 1; % if at the wall, move away
else
    minY = robotPos(1) + 1;
    maxY = robotPos(1) + laserR;
    obsFind = obsMap(minY:maxY, robotPos(2)); %E
    if(~isempty(find(obsFind==0, 1))) %If zeros are found, then obstacle has been detected
       b1 = find(obsFind==0);
       obsDirection(1) = b1(1); %Want to move North
    end
end
    
% North
if((robotPos(1)-laserR < 1) && (robotPos(1) ~= 1))
    minY = 1;
    maxY =  robotPos(1) - 1;
    obsFind = flipud(obsMap(minY:maxY, robotPos(2))); %W
    if(~isempty(find(obsFind==0, 1))) %If zeros are found, then obstacle has been detected
       b1 = find(obsFind==0);
       obsDirection(2) = b1(1); %Want to move South
    end
elseif(robotPos(1) == 1)
    obsDirection(2) = 1; % if at the wall, move away
else
    minY = robotPos(1) - laserR;
    maxY = robotPos(1) - 1;
    obsFind = fliplr(obsMap(minY:maxY, robotPos(2))); %W
    if(~isempty(find(obsFind==0, 1))) %If zeros are found, then obstacle has been detected
       b1 = find(obsFind==0);
       obsDirection(2) = b1(1); %Want to move South
    end
end
    
[val, avoidTurn1] = max(obsDirection);
% Use val (distance to object) to determine how fast to move away. 
% The greater the val, the smaller the move away velocity should be.
if(val > 0 && val <= 2 && sum(obsDirection) > 0)
    avoidVel = 3;
elseif(val > 2 && val <= 3)
    avoidVel = 2;
elseif(val > 3 && val <= 5)
    avoidVel = 1;
else
    avoidVel = 0;
end

%Work again to combine multiple obstacles in the area
if(length(find(obsDirection > 0)) > 1)
    obsDirection(avoidTurn1) = 0;
    [val, avoidTurn2] = max(obsDirection);
    %Assume same distance and same val term

    switch avoidTurn1+avoidTurn2 
        case 1;
            avoidTurn = 1; %N
        case 2;
            avoidTurn = 2; %S
        case 3;
            avoidTurn = 3; %E (or N+S)
        case 4;
            avoidTurn = 4; %W (or N+E)
        case 5;
            avoidTurn = 2; %N+W = go E    
        case 6;
            avoidTurn = 1; %S+W = go N
        case 7;
            avoidTurn = 2; %E+W = go S
        otherwise
            avoidTurn = avoidTurn1; % Default
    end
else
    avoidTurn = avoidTurn1;
end     

avoidVars = [avoidVel avoidTurn];
end