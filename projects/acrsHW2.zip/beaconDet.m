function beaconVars = beaconDet(beaMap, beaconR, robotPos)
% beaMap contains the beacon layer (20 pixels by 20 pixels)
% robotPos has the current robot position

beaDirection = [0, 0, 0, 0]; % Closeness in N,S,E,W
beaconFound = 0; % Change to 1 when found
scan = 1;

while(scan < 4)
    % East
    if((robotPos(2)+beaconR > 20) && (robotPos(2) ~= 20))
        minX = robotPos(2) + 1;
        maxX =  20;
        beaFind = beaMap(robotPos(1), minX:maxX); %N
        if(~isempty(find(beaFind==0, 1))) %If zeros are found, then beacon has been detected
           b1 = find(beaFind==0);
           beaDirection(3) = b1(1); %Want to move East
           break;
        end
    elseif(robotPos(2) == 20) %This is as far East as you can go, no need to scan further
        beaDirection(3) = 0;
    else
        minX = robotPos(2) + 1;
        maxX = robotPos(2) + beaconR;
        beaFind = beaMap(robotPos(1), minX:maxX); %N
        if(~isempty(find(beaFind==0, 1))) %If zeros are found, then beacon has been detected
           b1 = find(beaFind==0);
           beaDirection(3) = b1(1); %Want to move East
           break;
        end
    end
    scan = 1;
    
    % West
    if((robotPos(2)-beaconR < 1) && (robotPos(2) ~= 1))
        minX = 1;
        maxX =  robotPos(2) - 1;
        beaFind = fliplr(beaMap(robotPos(1), minX:maxX)); %S
        if(~isempty(find(beaFind==0, 1))) %If zeros are found, then beacon has been detected
           b1 = find(beaFind==0);
           beaDirection(4) = b1(1); %Want to move West
           break;
        end
    elseif(robotPos(2) == 1)
        beaDirection(4) = 0;
    else
        minX = robotPos(2) - beaconR;
        maxX = robotPos(2) - 1;
        beaFind = fliplr(beaMap(robotPos(1), minX:maxX)); %S
        if(~isempty(find(beaFind==0, 1))) %If zeros are found, then beacon has been detected
           b1 = find(beaFind==0);
           beaDirection(4) = b1(1); %Want to move West
           break;
        end
    end
    scan = 2;
    
    % South
    if((robotPos(1)+beaconR > 20) && (robotPos(1) ~= 20))
        minY = robotPos(1) + 1;
        maxY =  20;
        beaFind = beaMap(minY:maxY, robotPos(2)); %E
        if(~isempty(find(beaFind==0, 1))) %If zeros are found, then beacon has been detected
           b1 = find(beaFind==0);
           beaDirection(2) = b1(1); %Want to move South
           break;
        end
    elseif(robotPos(1) == 20)
        beaDirection(2) = 0;
    else
        minY = robotPos(1) + 1;
        maxY = robotPos(1) + beaconR;
        beaFind = beaMap(minY:maxY, robotPos(2)); %E
        if(~isempty(find(beaFind==0, 1))) %If zeros are found, then beacon has been detected
           b1 = find(beaFind==0);
           beaDirection(2) = b1(1); %Want to move South
           break;
        end
    end
    scan = 3;

    % North
    if((robotPos(1)-beaconR < 1) && (robotPos(1) ~= 1))
        minY = 1;
        maxY =  robotPos(1) - 1;
        beaFind = flipud(beaMap(minY:maxY, robotPos(2))); %W
        if(~isempty(find(beaFind==0, 1))) %If zeros are found, then beacon has been detected
           b1 = find(beaFind==0);
           beaDirection(1) = b1(1); %Want to move North
           break;
        end
    elseif(robotPos(1) == 1)
        beaDirection(1) = 0;
    else
        minY = robotPos(1) - beaconR;
        maxY = robotPos(1) - 1;
        beaFind = fliplr(beaMap(minY:maxY, robotPos(2))); %W
        if(~isempty(find(beaFind==0, 1))) %If zeros are found, then beacon has been detected
           b1 = find(beaFind==0);
           beaDirection(1) = b1(1); %Want to move North
           break;
        end
    end
    scan = 4;
end
[val, beaconTurn] = max(beaDirection);

% Use val (distance to beacon) to determine how fast to move toward. 
% The greater the val, the greater the move toward velocity should be.
if(val <= 1 && sum(beaDirection) > 0)
    beaconVel = 1;
    if(val == 1)
        beaconFound = 1;
    end
elseif(val == 2)
    beaconVel = 2;
elseif(val == 3)
    beaconVel = 3;
else
    beaconVel = 0;
    beaconTurn = 0;
end

beaconVars = [beaconVel, beaconTurn, beaconFound];
end