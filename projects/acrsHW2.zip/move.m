function newRobotPos = move(combVectors, CurRobotPos)
%combVectors(1): Direction: 1=North, 2=South, 3=East, 4=West
%combVectors(2): Velocities meters/frame

xPos = CurRobotPos(1); yPos = CurRobotPos(2);
switch combVectors(2) %Use direction
    case 1,
        xPos = CurRobotPos(1) - combVectors(1); % North
    case 2,
        xPos = CurRobotPos(1) + combVectors(1); % South
    case 3,
         yPos = CurRobotPos(2) + combVectors(1); % East
    case 4,
        yPos = CurRobotPos(2) - combVectors(1); % West
    otherwise
end

% Make sure the point is on the map
if xPos < 1
    xPos = 1;
elseif xPos > 20
    xPos = 20;
end

if yPos < 1
    yPos = 1;
elseif yPos > 20
    yPos = 20;
end

newRobotPos = [xPos,yPos]

end
