% Written by: Mason Nixon
% Version date: 11/19/2011

clear all
clc

g = 1; % Growth factor

%Reading in world file
fileName='Planet.wld';

[fid,msg] = fopen(fileName,'r+');
if fid < 0
    fprintf('Error in readDataFile: %s.\n', msg)
    dataMatrix=0;
else
    [dataMatrix,count]=fscanf(fid,'%c',inf);
    if count == 0
        fprintf('Error in readDataFile: No data in file.\n')
        fclose(fid);
    else
        % Parse dataMatrix
        fclose(fid);
    end
end

%Need to parse the char string into points for the grid 
dataValues = strread(dataMatrix, '%s', 'delimiter',' ');

% Origin x_position y_position  
%   Defines the starting (x,y) position of the robot  
origin(1,1:2) = [str2double(dataValues{2}),str2double(dataValues{3})];
origin(1,3) = str2double(dataValues{4}); % Orientation
robotDim = [str2double(dataValues{5}),str2double(dataValues{6})];
goal = [str2double(dataValues{8}),str2double(dataValues{9})];
% Note: must add 1 everywhere since matlab index starts with 1
a3 = 1;
for a2 = 10:(length(dataValues))
    if(length(dataValues{a2}) == 8) % Find all Obstacles
        obstacle(a3,1:2) = [str2double(dataValues{a2+1}),str2double(dataValues{a2+2})];
        obstacle(a3,3:4) = [str2double(dataValues{a2+3}),str2double(dataValues{a2+4})];
        a3 = a3 + 1;
    end
end
robotPos = [origin(1,1:2) robotDim]; 

% Compute paths using Visibility Graphs roadmap method
edges = visGraph(robotPos, obstacle, goal, g);

% Update map
% updateMap(g, robotPos, obstacle, goal, edges);

% Search for optimal path
optEdges = optimalPath(robotPos, goal, edges);

% Optimal path
optimalMap(robotPos, obstacle, goal, optEdges);

disp('End of run')
