function visOutput = visGraph(robot, obstacle, goal, g)
% edges = 0;

% Identify vertices of obstacles
[b1,b2] = size(obstacle); % Determine the number of obstacle in the room
% Note: Need if/else statements to fix cases where lines lie outside of
% the plane of the 20x20 space.
a1 = 1;
for a2 = 1:b1
    if (obstacle(a2,1)-g) < 0
        vertices(a1,1:2)=[0 obstacle(a2,2)-g];
    elseif (obstacle(a2,2)-g) < 0
        vertices(a1,1:2)=[obstacle(a2,1)-g 0];
    elseif (((obstacle(a2,2)-g) < 0) && ((obstacle(a2,1)-g) < 0))
        vertices(a1,1:2)=[0 0];
    else
        vertices(a1,1:2)=[obstacle(a2,1)-g obstacle(a2,2)-g]; % Top left
    end
    a1 = a1 + 1;
    if (obstacle(a2,2)-g) < 0
        vertices(a1,1:2)=[obstacle(a2,1)+obstacle(a2,3)+g 0];
    elseif (obstacle(a2,1)+obstacle(a2,3)+g) > 20
        vertices(a1,1:2)=[20 obstacle(a2,2)-g];
    elseif ((obstacle(a2,1)+obstacle(a2,3)+g) > 20) && ((obstacle(a2,2)-g) < 0)
        vertices(a1,1:2)=[20 0];
    else
        vertices(a1,1:2)=[obstacle(a2,1)+obstacle(a2,3)+g obstacle(a2,2)-g]; % Top right
    end
    a1 = a1 + 1;
    
    if (obstacle(a2,1)-g) < 0
        vertices(a1,1:2)=[0 obstacle(a2,2)+obstacle(a2,4)+g];
    elseif (obstacle(a2,2)+obstacle(a2,4)+g) > 20
        vertices(a1,1:2)=[obstacle(a2,1)-g 20];
    elseif ((obstacle(a2,1)-g) < 0) && ((obstacle(a2,2)+obstacle(a2,4)+g) > 20)
        vertices(a1,1:2)=[0 20];
    else
        vertices(a1,1:2)=[obstacle(a2,1)-g obstacle(a2,2)+obstacle(a2,4)+g]; % Bottom left
    end
    a1 = a1 + 1;
    
    if (obstacle(a2,1)+obstacle(a2,3)+g) > 20
        vertices(a1,1:2)=[20 obstacle(a2,2)+obstacle(a2,4)+g];
    elseif (obstacle(a2,2)+obstacle(a2,4)+g) > 20
        vertices(a1,1:2)=[obstacle(a2,1)+obstacle(a2,3)+g 20];
    elseif ((obstacle(a2,1)+obstacle(a2,3)+g) > 20 && (obstacle(a2,2)+obstacle(a2,4)+g) > 20)
        vertices(a1,1:2)=[20 20];
    else
        vertices(a1,1:2)=[obstacle(a2,1)+obstacle(a2,3)+g obstacle(a2,2)+obstacle(a2,4)+g]; % Bottom right
    end
    a1 = a1 + 1;
end

% Make all possible edges
% Start to vertices
a4 = 1;
for a3 = 1:length(vertices)
    % Determine visibility
    x1 = robot(1,1); y1 = robot(1,2);
    x2 = vertices(a3,1); y2 = vertices(a3,2);
    
    syms x y
    x = x1 + ((x2-x1)/(y2-y1))*(y-y1);
    % Try different obstacle horizontal sides
    for a5 = 2:2:length(vertices) % Skip repeats
        testY = vertices(a5,2);
        testX = subs(x,y,testY);
        if (testY >= y2)
            visibility = 1;
        elseif (testX > (vertices(a5-1,1)) && (testX < vertices(a5,1)))
            if (testX - floor(testX)) > 0 % Prob on an intercept
                visibility = 0;
                break;
            else
                visibility = 1;
            end
        elseif ((testX > 20) || (testX < 0)) % If point is off the map, then vertex is visible
            visiblity = 1;
        else % Do nothing (<-not sure if this is a good idea yet)
        end
    end
    
    if (visibility == 1)
        horzEdges(a4) = a3;
        a4 = a4 + 1;
    else % If vertex cannot be seen, do not draw the edge
    end
end
a1 = 1;
for a3 = 1:length(vertices)
    % Determine visibility
    x1 = robot(1,1); y1 = robot(1,2);
    x2 = vertices(a3,1); y2 = vertices(a3,2);
    clear x y
    syms x y
    y = y1 + ((y2-y1)/(x2-x1))*(x-x1);
    % Try different obstacle vertical sides
    xVert(1:b1) = 1:4:length(vertices);
    
    for a5 = 2:length(vertices)%xVert(1:3)
        testX = vertices(a5,1);
        testY = subs(y,x,testX);
        if (testY > (vertices(a5-1,2)) && (testY < vertices(a5,2)))
            if (testY - floor(testY)) > 0 % Prob on an intercept
                visibility = 0;
                break;
            else
                visibility = 1;
            end
        elseif (testX >= x2)
            visibility = 1;  
        elseif ((testY > 20) || (testY < 0)) % If point is off the map, then vertex is visible
            visibility = 1;
        else % Do nothing (<-not sure if this is a good idea yet)
        end
    end

    if (((visibility == 1)) && ~isempty(find(horzEdges==a3)))
        edges(a4,:) = [robot(1,1) vertices(a3,1) robot(1,2) vertices(a3,2)];
        a4 = a4 + 1;
    else % If vertex cannot be seen, do not draw the edge
    end
end

% Goal to vertices
for a3 = 1:length(vertices)
    % Determine visibility
    x1 = goal(1,1); y1 = goal(1,2);
    x2 = vertices(a3,1); y2 = vertices(a3,2);
    syms x y
    x = x1 + ((x2-x1)/(y2-y1))*(y-y1);
    % Try different obstacle horizontal sides
    for a5 = 2:2:length(vertices) % Skip repeats
        testY = vertices(a5,2);
        testX = subs(x,y,testY);
        if (testY >= y2)
            visibility = 1;
        elseif (testX > (vertices(a5-1,1)) && (testX < vertices(a5,1)))
            if (testX - floor(testX)) > 0 % Prob on an intercept
                visibility = 0;
                break;
            else
                visibility = 1;
            end
        elseif ((testX > 20) || (testX < 0)) % If point is off the map, then vertex is visible
            visiblity = 1;
        else % Do nothing (<-not sure if this is a good idea yet)
        end
    end
    
    if (visibility == 1)
        horzEdges(a4) = a3;
        a4 = a4 + 1;
    else % If vertex cannot be seen, do not draw the edge
    end
end

for a3 = 1:length(vertices)
    % Determine visibility
    x1 = goal(1,1); y1 = goal(1,2);
    x2 = vertices(a3,1); y2 = vertices(a3,2);
    clear x y
    syms x y
    y = y1 + ((y2-y1)/(x2-x1))*(x-x1);
    % Try different obstacle vertical sides
    xVert(1:b1) = 1:4:length(vertices);
    
    for a5 = 2:length(vertices)%xVert(1:3)
        testX = vertices(a5,1);
        testY = subs(y,x,testX);
        if (testY > (vertices(a5-1,2)) && (testY < vertices(a5,2)))
            if (testY - floor(testY)) > 0 % Prob on an intercept
                visibility = 0;
                break;
            else
                visibility = 1;
            end
        elseif (testX >= x2)
            visibility = 1;  
        elseif ((testY > 20) || (testY < 0)) % If point is off the map, then vertex is visible
            visibility = 1;
        else % Do nothing (<-not sure if this is a good idea yet)
        end
    end

    if (((visibility == 1)) && ~isempty(find(horzEdges==a3)))
        edges(a4,:) = [goal(1,1) vertices(a3,1) goal(1,2) vertices(a3,2)];
        a4 = a4 + 1;
    else % If vertex cannot be seen, do not draw the edge
    end
end

% Obstacle vertex edges
for a5 = 1:length(vertices)
    for a3 = 1:length(vertices)
        % Determine visibility
        x1 = vertices(a5,1); y1 = vertices(a5,2);
        x2 = vertices(a3,1); y2 = vertices(a3,2);
        syms x y
        x = x1 + ((x2-x1)/(y2-y1))*(y-y1);
        % Try different obstacle horizontal sides
        for a5 = 2:2:length(vertices) % Skip repeats
            testY = vertices(a5,2);
            testX = subs(x,y,testY);
            if (testY >= y2)
                visibility = 1;
                %         elseif (((testY < y2) && (testX == x2)) && (testY ~= 0))
                %             visibility = 0;
                %             break;
            elseif (testX > (vertices(a5-1,1)) && (testX < vertices(a5,1)))
                if (testX - floor(testX)) > 0 % Prob on an intercept
                    visibility = 0;
                    break;
                else
                    visibility = 1;
                end
            elseif ((testX > 20) || (testX < 0)) % If point is off the map, then vertex is visible
                visiblity = 1;
            else % Do nothing (<-not sure if this is a good idea yet)
            end
        end
        
        if (visibility == 1)
            %         edges(a4,:) = [vertices(a5,1) vertices(a3,1) vertices(a5,2) vertices(a3,2)];
            horzEdges(a4) = a3;
            a4 = a4 + 1;
        else % If vertex cannot be seen, do not draw the edge
        end
    end
end

for a5 = 1:length(vertices)
    for a3 = 1:length(vertices)
        % Determine visibility
        x1 = vertices(a5,1); y1 = vertices(a5,2);
        x2 = vertices(a3,1); y2 = vertices(a3,2);
        clear x y
        syms x y
        y = y1 + ((y2-y1)/(x2-x1))*(x-x1);
        % Try different obstacle vertical sides
        xVert(1:b1) = 1:4:length(vertices);
        
        for a5 = 2:length(vertices)%xVert(1:3)
            testX = vertices(a5,1);
            testY = subs(y,x,testX);
            if (testY > (vertices(a5-1,2)) && (testY < vertices(a5,2)))
                if (testY - floor(testY)) > 0 % Prob on an intercept
                    visibility = 0;
                    break;
                else
                    visibility = 1;
                end
            elseif (testX >= x2)
                visibility = 1;
            elseif ((testY > 20) || (testY < 0)) % If point is off the map, then vertex is visible
                visibility = 1;
            else % Do nothing (<-not sure if this is a good idea yet)
            end
        end
        
        if (((visibility == 1)) && ~isempty(find(horzEdges==a3)))
            edges(a4,:) = [vertices(a5,1) vertices(a3,1) vertices(a5,2) vertices(a3,2)];
            a4 = a4 + 1;
        else % If vertex cannot be seen, do not draw the edge
        end
    end
end

% for a5 = 1:length(vertices)
%     for a3 = 1:length(vertices)
%         edges(a4,:) = [vertices(a5,1) vertices(a3,1) vertices(a5,2) vertices(a3,2)];
%         a4 = a4 + 1;
%     end
% end

% Need to get rid of all 0,0,0,0 lines
a8 = 1;
for a7 = 1:length(edges)
   if (edges(a7,1:4) == [0 0 0 0])
   else
       newEdges(a8,1:4) = edges(a7,1:4);
       a8 = a8 + 1;
   end    
end
edges = newEdges;

visOutput = edges;

end