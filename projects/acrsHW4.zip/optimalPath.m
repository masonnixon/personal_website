function optEdges = optimalPath(robot, goal, edges)

% Compare points at start position
a2 = 1; a3 = 1; a4 = 1; startGoal = 0;
for a1 = 1:length(edges)
    if ((edges(a1,1)==robot(1,1)) && (edges(a1,3)==robot(1,2)))
        startEdges(a2,1:4) = edges(a1,1:4);
        a2 = a2 + 1;
        if ((edges(a1,2)==goal(1,1)) && (edges(a1,4) == robot(1,2)))
            startGoal = edges(a1,1:4);
        else
        end
    elseif ((edges(a1,1)==goal(1,1)) && (edges(a1,3)==goal(1,2)))
        endEdges(a3,1:4) = edges(a1,1:4);
        a3 = a3 + 1;
    else
        obsEdges(a4,1:4) = edges(a1,1:4);
        a4 = a4 + 1;
    end
end

% Find path to goal
if(startGoal == 0)
    pathFound = 0; obsInd =1; startInd = 1;
    [a,b] = max(startEdges(:,2));
    robotPath(1,1:4) = startEdges(b,1:4);
    
    for a1 = 1:length(endEdges)
        if((endEdges(a1,2)==startEdges(b,2)) && (endEdges(a1,4)==startEdges(b,4)))
            robotPath(2,1:4) = endEdges(a1,1:4);
            endInd = a1; obsInd = a2;
            pathFound = 1;
            break;
        else
        end
    end
    
    if(pathFound ~= 1) % Keep trying
        pathFound = 0; obsInd =1; startInd = 1;
        [a,b] = min(startEdges(:,4));
        robotPath(1,1:4) = startEdges(b,1:4);
        
        for a1 = 1:length(endEdges)
            if((endEdges(a1,2)==startEdges(b,2)) && (endEdges(a1,4)==startEdges(b,4)))
                robotPath(2,1:4) = endEdges(a1,1:4);
                endInd = a1; obsInd = a2;
                pathFound = 1;
                break;
            else
            end
        end
    else
    end
else
    robotPath = startGoal; % Single edge from origin to goal
end

optEdges = robotPath;

end
