function mapOutput = updateMap(g, robot, obstacle, goal, edges)
figure(1)
% Plot edges
if ~isempty(edges(:,:))
    [rows,cols] = size(edges);
    for a1 = 1:rows
        plot(edges(a1,1:2), edges(a1,3:4))
        hold on
    end
else
end

% Plot Obstacles
[b1,b2] = size(obstacle); % Determine the number of obstacle in the room
for a1 = 1:b1
    rectangle('Position',[obstacle(a1,1:2)-g obstacle(a1,3:4)+2*g],'FaceColor','black')
end

% Plot Robot and goal
rectangle('Position',robot,'FaceColor','r')
rectangle('Position',[goal 1 1],'FaceColor','y')

% daspect([1,1,1]) % Makes the plot to equal scale on the axes
xlim([0 20])
ylim([0 20])
set(gca,'ydir','reverse');
title('Room Map')
hold on
mapOutput = 0;

end