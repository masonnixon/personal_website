Name: Mason Nixon
Version Date: 11/23/2011
Course: GA Tech ECE 8843: Autonomous Control of Robotic Systems
Description: HW4 - Robot Path Planning
The following is instruction on how to run the MATLAB (R2009b) m-files.
Due: 11/23/2011
Files included: optimalMap.m, optimalPath, updateMap.m, visGraph.m, HW4main.m

Instructions: With these five (5) m-files in the same directory as 
Planet.wld, open HW4main.m and run it. The program will display a plot of 
the room with the optimal path in blue from the red robot to the yellow
goal point.